late String referCode;
 String languageStateName = '';
late int activeCardIndex;


// const String currency = "USD";