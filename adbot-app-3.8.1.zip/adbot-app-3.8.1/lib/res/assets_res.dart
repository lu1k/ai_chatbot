/// Generated file. Do not edit.

// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars
class AssetsRes {
  static const String PLUGIN_NAME = 'adbot';
  static const String PLUGIN_VERSION = '3.7.0+38';
  static const String APPLE_PAY = 'assets/apple_pay.json';
  static const String GOOGLE_PAY = 'assets/google_pay.json';
  static const String DIET_CHART = 'assets/icon/diet_chart.svg';
}
